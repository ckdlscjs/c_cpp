#pragma once
//Macro
#define WIN32_LEAN_AND_MEAN					//���� ������ �ʴ� ������ Windows ������� �����մϴ�.
#define NOMINMAX							//window�� min,max�� �ƴ� std�� min,max��������� ��ũ��
#define _SILENCE_CXX17_CODECVT_HEADER_DEPRECATION_WARNING

#define _ASEERTION_NULCHK(result, message) assert(result && message)
#define _ASEERTION_CREATE(result, message) assert(result == S_OK && message)
#define _DEGTORAD(DEG) DEG / 180.0f * XM_PI
#define _RADTODEG(RAD) RAD / XM_PI * 180.0f
#define _EPSILON 1e-20f
#define _CLAMP(val, low, high) Clamp(val, low, high)
#define VK_MOUSE_MOVE 255
#define _CSGroup 64
#define _Dispatch_Vertices(count) (count / 3) / _CSGroup + ((count / 3) % _CSGroup ? 1 : 0)
#define _HashNotInitialize size_t(-1)
#define _RPKey size_t
#define _ToMask32(VAL) (1 << static_cast<uint32_t>(VAL))
//App Header
#include <cstdlib>
#include <crtdbg.h>
#include <Windows.h>
#include <windowsx.h>						// GET_X_LPARAM, GET_Y_LPARAM ��ũ�� ����� ���� ����
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <functional>
#include <codecvt>							//need to w to m, m to w
#include <random>							//������������������(mt19937)
#include <ctime>							//������������������(mt19937)
#include <typeindex>						//std::type_index
#include <array>
#include <fstream>
#include <bitset>

//d3d Header
#include <d3d11.h>
#include <DirectXMath.h>					//XMMATRIX
#include <d3dcompiler.h>					//d3dcomplie, ���̴�����������߰�
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")		//d3dcomplie, ���̴�����������߰�

#include <directXTex/DirectXTex.h>			
#pragma comment(lib, "DirectXTex.lib")

#include <directXTK/DDSTextureLoader.h>
#include <directXTK/WICTextureLoader.h>
#pragma comment(lib, "DirectXTK.lib")


//assimp
#pragma comment(lib, "assimp-vc145-mtd.lib")
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>
#include <assimp/version.h>

using namespace DirectX;

//#include "bits/stdc++.h"





//�����Լ���
template<typename T>
inline const T& Clamp(const T& val, const T& low, const T& high)
{
	_ASEERTION_NULCHK(low <= high, "low larger then high!");
	if (val < low) return low;
	else if (val > high) return high;
	else return val;
}

inline std::wstring _tomw(std::string str)
{
	std::wstring content;
	content.assign(str.begin(), str.end());
	return content;
}

inline std::string _towm(std::wstring wstr)
{
	std::wstring_convert<std::codecvt_utf8<wchar_t>> myconv;
	return myconv.to_bytes(wstr);
}

inline std::string _tocm(const char* _cstr)
{
	return std::string(_cstr);
}

inline std::wstring _tocw(const char* _cstr)
{
	return _tomw(_tocm(_cstr));
}

inline size_t Hasing_wstring(const std::wstring& str)
{
	// FNV-1a (64��Ʈ) ���� ����
	size_t hash = 14695981039346656037ULL; // FNV_PRIME_64
	for (wchar_t c : str) {
		hash ^= static_cast<size_t>(c);
		hash *= 1099511628211ULL; // FNV_OFFSET_64
	}
	return hash;
}

inline size_t Hasing_float(const float& value)
{
	// FNV-1a (64��Ʈ) ���� ����
	size_t hash = 14695981039346656037ULL; // FNV_PRIME_64
	hash ^= std::hash<float>{}(value);
	hash *= 1099511628211ULL; // FNV_OFFSET_64
	return hash;
}

inline void hash_combine(std::size_t& seed, std::size_t hashValue) {
	seed ^= hashValue + 0x9e3779b9 + (seed << 6) + (seed >> 2);
}



