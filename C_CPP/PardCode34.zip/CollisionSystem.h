#pragma once
#include "BaseSystem.h"

class Collider;
class Frustum;
class Sphere;
class Box;

class CollisionSystem : public BaseSystem<CollisionSystem>
{
	friend class BaseSystem<CollisionSystem>;	//CRTP������ ���� friend����
private:
	CollisionSystem();
	CollisionSystem(const CollisionSystem&) = delete;
	CollisionSystem& operator=(const CollisionSystem&) = delete;
	CollisionSystem(CollisionSystem&&) = delete;
	CollisionSystem& operator=(CollisionSystem&&) = delete;
public:
	~CollisionSystem();
	void Init();
	void Frame(float deltatime);
	size_t CreateCollider(const std::wstring& szName, const std::vector<Vector3>* iTriangleCount, E_Collider collider);	//�ö��̴� ���ø� Ȥ�� ���ڸ� �޾Ƽ� �����°Բ� �������ٰ��ΰ� �б��Լ�
	void SetColliderDebugData(const size_t hash, CB_Debug_Box& cb);
	void SetColliderDebugData(const size_t hash, CB_Debug_Sphere& cb);
private:
	template<typename T, typename... Types>
	size_t AddCollider(const std::wstring& szName, Types&&... args);
	bool IsCollision(const Frustum& frustum, size_t hash, const Matrix4x4& matWorld);
	bool IsCollision(const Frustum& frustum, const Box& box, const Matrix4x4& matWorld);
	bool IsCollision(const Frustum& frustum, const Sphere& sphere, const Matrix4x4& matWorld);
	bool IsCollision(const Vector4& rayOrigin, const Vector4& rayDir, size_t hash);
	bool IsCollision(const Vector4& rayOrigin, const Vector4& rayDir, const Box& box);
	bool IsCollision(const Vector4& rayOrigin, const Vector4& rayDir, const Sphere& sphere);
	bool IsCollision(const Vector4& rayOrigin, const Vector4& rayDir, const Vector3& v0, const Vector3& v1, const Vector3& v2, float& fDist);
	
	float fSphereTesselateFactor = 2.0f;
	std::unordered_map<size_t, Collider*> m_Colliders;
};
#define _CollisionSystem CollisionSystem::GetInstance()

template<typename T, typename... Types>
inline size_t CollisionSystem::AddCollider(const std::wstring& szName, Types&& ...args)
{
	size_t hash = Hasing_wstring(szName);
	if (m_Colliders.find(hash) != m_Colliders.end()) return hash;
	//��ü������ �����̳ʿ� ���
	T* newCollider = new T(std::forward<Types>(args)...);
	_ASEERTION_NULCHK(newCollider, typeid(T).name());
	m_Colliders[hash] = newCollider;
	return hash;
}
