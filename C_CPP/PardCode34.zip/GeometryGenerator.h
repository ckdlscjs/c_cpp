////***************************************************************************************
//// GeometryGenerator.h by Frank Luna (C) 2011 All Rights Reserved.
////   
//// Defines a static class for procedurally generating the geometry of 
//// common mathematical objects.
////
//// All triangles are generated "outward" facing.  If you want "inward" 
//// facing triangles (for example, if you want to place the camera inside
//// a sphere to simulate a sky), you will need to:
////   1. Change the Direct3D cull mode or manually reverse the winding order.
////   2. Invert the normal.
////   3. Update the texture coordinates and tangent vectors.
////***************************************************************************************
//
//#ifndef GEOMETRYGENERATOR_H
//#define GEOMETRYGENERATOR_H
//
//#include "d3dUtil.h"
//
//class GeometryGenerator
//{
//public:
//	struct Vertex
//	{
//		Vertex(){}
//		Vertex(const XMFLOAT3& p, const XMFLOAT3& n, const XMFLOAT3& t, const XMFLOAT2& uv)
//			: Position(p), Normal(n), TangentU(t), TexC(uv){}
//		Vertex(
//			float px, float py, float pz, 
//			float nx, float ny, float nz,
//			float tx, float ty, float tz,
//			float u, float v)
//			: Position(px,py,pz), Normal(nx,ny,nz),
//			  TangentU(tx, ty, tz), TexC(u,v){}
//
//		XMFLOAT3 Position;
//		XMFLOAT3 Normal;
//		XMFLOAT3 TangentU;
//		XMFLOAT2 TexC;
//	};
//
//	struct MeshData
//	{
//		std::vector<Vertex> Vertices;
//		std::vector<UINT> Indices;
//	};
//
//	///<summary>
//	/// Creates a box centered at the origin with the given dimensions.
//	///</summary>
//	void CreateBox(float width, float height, float depth, MeshData& meshData);
//
//	///<summary>
//	/// Creates a sphere centered at the origin with the given radius.  The
//	/// slices and stacks parameters control the degree of tessellation.
//	///</summary>
//	void CreateSphere(float radius, UINT sliceCount, UINT stackCount, MeshData& meshData);
//
//	///<summary>
//	/// Creates a geosphere centered at the origin with the given radius.  The
//	/// depth controls the level of tessellation.
//	///</summary>
//	void CreateGeosphere(float radius, UINT numSubdivisions, MeshData& meshData);
//
//	///<summary>
//	/// Creates a cylinder parallel to the y-axis, and centered about the origin.  
//	/// The bottom and top radius can vary to form various cone shapes rather than true
//	// cylinders.  The slices and stacks parameters control the degree of tessellation.
//	///</summary>
//	void CreateCylinder(float bottomRadius, float topRadius, float height, UINT sliceCount, UINT stackCount, MeshData& meshData);
//
//	///<summary>
//	/// Creates an mxn grid in the xz-plane with m rows and n columns, centered
//	/// at the origin with the specified width and depth.
//	///</summary>
//	void CreateGrid(float width, float depth, UINT m, UINT n, MeshData& meshData);
//
//	///<summary>
//	/// Creates a quad covering the screen in NDC coordinates.  This is useful for
//	/// postprocessing effects.
//	///</summary>
//	void CreateFullscreenQuad(MeshData& meshData);
//
//private:
//	void Subdivide(MeshData& meshData);
//	void BuildCylinderTopCap(float bottomRadius, float topRadius, float height, UINT sliceCount, UINT stackCount, MeshData& meshData);
//	void BuildCylinderBottomCap(float bottomRadius, float topRadius, float height, UINT sliceCount, UINT stackCount, MeshData& meshData);
//};
//
//#endif // GEOMETRYGENERATOR_H

////***************************************************************************************
//// GeometryGenerator.cpp by Frank Luna (C) 2011 All Rights Reserved.
////***************************************************************************************
//
//#include "GeometryGenerator.h"
//#include "MathHelper.h"
//
//void GeometryGenerator::CreateBox(float width, float height, float depth, MeshData& meshData)
//{
//	//
//	// Create the iTriangleCount.
//	//
//
//	Vertex v[24];
//
//	float w2 = 0.5f*width;
//	float h2 = 0.5f*height;
//	float d2 = 0.5f*depth;
//    
//	// Fill in the front face vertex data.
//	v[0] = Vertex(-w2, -h2, -d2, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 10.0f);
//	v[1] = Vertex(-w2, +h2, -d2, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f);
//	v[2] = Vertex(+w2, +h2, -d2, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f, 0.0f, 10.0f, 0.0f);
//	v[3] = Vertex(+w2, -h2, -d2, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f, 0.0f, 10.0f, 10.0f);
//
//	// Fill in the back face vertex data.
//	v[4] = Vertex(-w2, -h2, +d2, 0.0f, 0.0f, 1.0f, -1.0f, 0.0f, 0.0f, 10.0f, 10.0f);
//	v[5] = Vertex(+w2, -h2, +d2, 0.0f, 0.0f, 1.0f, -1.0f, 0.0f, 0.0f, 0.0f, 10.0f);
//	v[6] = Vertex(+w2, +h2, +d2, 0.0f, 0.0f, 1.0f, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f);
//	v[7] = Vertex(-w2, +h2, +d2, 0.0f, 0.0f, 1.0f, -1.0f, 0.0f, 0.0f, 10.0f, 0.0f);
//
//	// Fill in the top face vertex data.
//	v[8]  = Vertex(-w2, +h2, -d2, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 10.0f);
//	v[9]  = Vertex(-w2, +h2, +d2, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f);
//	v[10] = Vertex(+w2, +h2, +d2, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 10.0f, 0.0f);
//	v[11] = Vertex(+w2, +h2, -d2, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 10.0f, 10.0f);
//
//	// Fill in the bottom face vertex data.
//	v[12] = Vertex(-w2, -h2, -d2, 0.0f, -1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 10.0f, 10.0f);
//	v[13] = Vertex(+w2, -h2, -d2, 0.0f, -1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 10.0f);
//	v[14] = Vertex(+w2, -h2, +d2, 0.0f, -1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f);
//	v[15] = Vertex(-w2, -h2, +d2, 0.0f, -1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 10.0f, 0.0f);
//
//	// Fill in the left face vertex data.
//	v[16] = Vertex(-w2, -h2, +d2, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 10.0f);
//	v[17] = Vertex(-w2, +h2, +d2, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f);
//	v[18] = Vertex(-w2, +h2, -d2, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 10.0f, 0.0f);
//	v[19] = Vertex(-w2, -h2, -d2, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 10.0f, 10.0f);
//
//	// Fill in the right face vertex data.
//	v[20] = Vertex(+w2, -h2, -d2, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 10.0f);
//	v[21] = Vertex(+w2, +h2, -d2, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f);
//	v[22] = Vertex(+w2, +h2, +d2, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 10.0f, 0.0f);
//	v[23] = Vertex(+w2, -h2, +d2, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 10.0f, 10.0f);
//
//	meshData.Vertices.assign(&v[0], &v[24]);
// 
//	//
//	// Create the indices.
//	//
//
//	UINT i[36];
//
//	// Fill in the front face index data
//	i[0] = 0; i[1] = 1; i[2] = 2;
//	i[3] = 0; i[4] = 2; i[5] = 3;
//
//	// Fill in the back face index data
//	i[6] = 4; i[7]  = 5; i[8]  = 6;
//	i[9] = 4; i[10] = 6; i[11] = 7;
//
//	// Fill in the top face index data
//	i[12] = 8; i[13] =  9; i[14] = 10;
//	i[15] = 8; i[16] = 10; i[17] = 11;
//
//	// Fill in the bottom face index data
//	i[18] = 12; i[19] = 13; i[20] = 14;
//	i[21] = 12; i[22] = 14; i[23] = 15;
//
//	// Fill in the left face index data
//	i[24] = 16; i[25] = 17; i[26] = 18;
//	i[27] = 16; i[28] = 18; i[29] = 19;
//
//	// Fill in the right face index data
//	i[30] = 20; i[31] = 21; i[32] = 22;
//	i[33] = 20; i[34] = 22; i[35] = 23;
//
//	meshData.Indices.assign(&i[0], &i[36]);
//}
//
//void GeometryGenerator::CreateSphere(float radius, UINT sliceCount, UINT stackCount, MeshData& meshData)
//{
//	meshData.Vertices.clear();
//	meshData.Indices.clear();
//
//	//
//	// Compute_SRV the iTriangleCount stating at the top pole and moving down the stacks.
//	//
//
//	// Poles: note that there will be texture coordinate distortion as there is
//	// not a unique point on the texture map to assign to the pole when mapping
//	// a rectangular texture onto a sphere.
//	Vertex topVertex(0.0f, +radius, 0.0f, 0.0f, +1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f);
//	Vertex bottomVertex(0.0f, -radius, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f);
//
//	meshData.Vertices.push_back( topVertex );
//
//	float phiStep   = XM_PI/stackCount;
//	float thetaStep = 2.0f*XM_PI/sliceCount;
//
//	// Compute_SRV iTriangleCount for each stack ring (do not count the poles as rings).
//	for(UINT i = 1; i <= stackCount-1; ++i)
//	{
//		float phi = i*phiStep;
//
//		// Vertices of ring.
//		for(UINT j = 0; j <= sliceCount; ++j)
//		{
//			float theta = j*thetaStep;
//
//			Vertex v;
//
//			// spherical to cartesian
//			v.Position.x = radius*sinf(phi)*cosf(theta);
//			v.Position.y = radius*cosf(phi);
//			v.Position.z = radius*sinf(phi)*sinf(theta);
//
//			// Partial derivative of P with respect to theta
//			v.TangentU.x = -radius*sinf(phi)*sinf(theta);
//			v.TangentU.y = 0.0f;
//			v.TangentU.z = +radius*sinf(phi)*cosf(theta);
//
//			XMVECTOR T = XMLoadFloat3(&v.TangentU);
//			XMStoreFloat3(&v.TangentU, XMVector3Normalize(T));
//
//			XMVECTOR p = XMLoadFloat3(&v.Position);
//			XMStoreFloat3(&v.Normal, XMVector3Normalize(p));
//
//			v.TexC.x = theta / XM_2PI;
//			v.TexC.y = phi / XM_PI;
//
//			meshData.Vertices.push_back( v );
//		}
//	}
//
//	meshData.Vertices.push_back( bottomVertex );
//
//	//
//	// Compute_SRV indices for top stack.  The top stack was written first to the vertex buffer
//	// and connects the top pole to the first ring.
//	//
//
//	for(UINT i = 1; i <= sliceCount; ++i)
//	{
//		meshData.Indices.push_back(0);
//		meshData.Indices.push_back(i+1);
//		meshData.Indices.push_back(i);
//	}
//	
//	//
//	// Compute_SRV indices for inner stacks (not connected to poles).
//	//
//
//	// Offset the indices to the index of the first vertex in the first ring.
//	// This is just skipping the top pole vertex.
//	UINT baseIndex = 1;
//	UINT ringVertexCount = sliceCount+1;
//	for(UINT i = 0; i < stackCount-2; ++i)
//	{
//		for(UINT j = 0; j < sliceCount; ++j)
//		{
//			meshData.Indices.push_back(baseIndex + i*ringVertexCount + j);
//			meshData.Indices.push_back(baseIndex + i*ringVertexCount + j+1);
//			meshData.Indices.push_back(baseIndex + (i+1)*ringVertexCount + j);
//
//			meshData.Indices.push_back(baseIndex + (i+1)*ringVertexCount + j);
//			meshData.Indices.push_back(baseIndex + i*ringVertexCount + j+1);
//			meshData.Indices.push_back(baseIndex + (i+1)*ringVertexCount + j+1);
//		}
//	}
//
//	//
//	// Compute_SRV indices for bottom stack.  The bottom stack was written last to the vertex buffer
//	// and connects the bottom pole to the bottom ring.
//	//
//
//	// South pole vertex was added last.
//	UINT southPoleIndex = (UINT)meshData.Vertices.size()-1;
//
//	// Offset the indices to the index of the first vertex in the last ring.
//	baseIndex = southPoleIndex - ringVertexCount;
//	
//	for(UINT i = 0; i < sliceCount; ++i)
//	{
//		meshData.Indices.push_back(southPoleIndex);
//		meshData.Indices.push_back(baseIndex+i);
//		meshData.Indices.push_back(baseIndex+i+1);
//	}
//}
// 
//void GeometryGenerator::Subdivide(MeshData& meshData)
//{
//	// Save a copy of the input geometry.
//	MeshData inputCopy = meshData;
//
//
//	meshData.Vertices.resize(0);
//	meshData.Indices.resize(0);
//
//	//       v1
//	//       *
//	//      / \
//	//     /   \
//	//  m0*-----*m1
//	//   / \   / \
//	//  /   \ /   \
//	// *-----*-----*
//	// v0    m2     v2
//
//	UINT numTris = inputCopy.Indices.size()/3;
//	for(UINT i = 0; i < numTris; ++i)
//	{
//		Vertex v0 = inputCopy.Vertices[ inputCopy.Indices[i*3+0] ];
//		Vertex v1 = inputCopy.Vertices[ inputCopy.Indices[i*3+1] ];
//		Vertex v2 = inputCopy.Vertices[ inputCopy.Indices[i*3+2] ];
//
//		//
//		// Generate the midpoints.
//		//
//
//		Vertex m0, m1, m2;
//
//		// For subdivision, we just care about the position component.  We derive the other
//		// vertex components in CreateGeosphere.
//
//		m0.Position = XMFLOAT3(
//			0.5f*(v0.Position.x + v1.Position.x),
//			0.5f*(v0.Position.y + v1.Position.y),
//			0.5f*(v0.Position.z + v1.Position.z));
//
//		m1.Position = XMFLOAT3(
//			0.5f*(v1.Position.x + v2.Position.x),
//			0.5f*(v1.Position.y + v2.Position.y),
//			0.5f*(v1.Position.z + v2.Position.z));
//
//		m2.Position = XMFLOAT3(
//			0.5f*(v0.Position.x + v2.Position.x),
//			0.5f*(v0.Position.y + v2.Position.y),
//			0.5f*(v0.Position.z + v2.Position.z));
//
//		//
//		// Add new geometry.
//		//
//
//		meshData.Vertices.push_back(v0); // 0
//		meshData.Vertices.push_back(v1); // 1
//		meshData.Vertices.push_back(v2); // 2
//		meshData.Vertices.push_back(m0); // 3
//		meshData.Vertices.push_back(m1); // 4
//		meshData.Vertices.push_back(m2); // 5
// 
//		meshData.Indices.push_back(i*6+0);
//		meshData.Indices.push_back(i*6+3);
//		meshData.Indices.push_back(i*6+5);
//
//		meshData.Indices.push_back(i*6+3);
//		meshData.Indices.push_back(i*6+4);
//		meshData.Indices.push_back(i*6+5);
//
//		meshData.Indices.push_back(i*6+5);
//		meshData.Indices.push_back(i*6+4);
//		meshData.Indices.push_back(i*6+2);
//
//		meshData.Indices.push_back(i*6+3);
//		meshData.Indices.push_back(i*6+1);
//		meshData.Indices.push_back(i*6+4);
//	}
//}
//
//void GeometryGenerator::CreateGeosphere(float radius, UINT numSubdivisions, MeshData& meshData)
//{
//	// Put a cap on the number of subdivisions.
//	numSubdivisions = MathHelper::Min(numSubdivisions, 5u);
//
//	// Approximate a sphere by tessellating an icosahedron.
//
//	const float X = 0.525731f; 
//	const float Z = 0.850651f;
//
//	XMFLOAT3 pos[12] = 
//	{
//		XMFLOAT3(-X, 0.0f, Z),  XMFLOAT3(X, 0.0f, Z),  
//		XMFLOAT3(-X, 0.0f, -Z), XMFLOAT3(X, 0.0f, -Z),    
//		XMFLOAT3(0.0f, Z, X),   XMFLOAT3(0.0f, Z, -X), 
//		XMFLOAT3(0.0f, -Z, X),  XMFLOAT3(0.0f, -Z, -X),    
//		XMFLOAT3(Z, X, 0.0f),   XMFLOAT3(-Z, X, 0.0f), 
//		XMFLOAT3(Z, -X, 0.0f),  XMFLOAT3(-Z, -X, 0.0f)
//	};
//
//	DWORD k[60] = 
//	{
//		1,4,0,  4,9,0,  4,5,9,  8,5,4,  1,8,4,    
//		1,10,8, 10,3,8, 8,3,5,  3,2,5,  3,7,2,    
//		3,10,7, 10,6,7, 6,11,7, 6,0,11, 6,1,0, 
//		10,1,6, 11,0,9, 2,11,9, 5,2,9,  11,2,7 
//	};
//
//	meshData.Vertices.resize(12);
//	meshData.Indices.resize(60);
//
//	for(UINT i = 0; i < 12; ++i)
//		meshData.Vertices[i].Position = pos[i];
//
//	for(UINT i = 0; i < 60; ++i)
//		meshData.Indices[i] = k[i];
//
//	for(UINT i = 0; i < numSubdivisions; ++i)
//		Subdivide(meshData);
//
//	// Project iTriangleCount onto sphere and scale.
//	for(UINT i = 0; i < meshData.Vertices.size(); ++i)
//	{
//		// Project onto unit sphere.
//		XMVECTOR n = XMVector3Normalize(XMLoadFloat3(&meshData.Vertices[i].Position));
//
//		// Project onto sphere.
//		XMVECTOR p = radius*n;
//
//		XMStoreFloat3(&meshData.Vertices[i].Position, p);
//		XMStoreFloat3(&meshData.Vertices[i].Normal, n);
//
//		// Derive texture coordinates from spherical coordinates.
//		float theta = MathHelper::AngleFromXY(
//			meshData.Vertices[i].Position.x, 
//			meshData.Vertices[i].Position.z);
//
//		float phi = acosf(meshData.Vertices[i].Position.y / radius);
//
//		meshData.Vertices[i].TexC.x = theta/XM_2PI;
//		meshData.Vertices[i].TexC.y = phi/XM_PI;
//
//		// Partial derivative of P with respect to theta
//		meshData.Vertices[i].TangentU.x = -radius*sinf(phi)*sinf(theta);
//		meshData.Vertices[i].TangentU.y = 0.0f;
//		meshData.Vertices[i].TangentU.z = +radius*sinf(phi)*cosf(theta);
//
//		XMVECTOR T = XMLoadFloat3(&meshData.Vertices[i].TangentU);
//		XMStoreFloat3(&meshData.Vertices[i].TangentU, XMVector3Normalize(T));
//	}
//}
//
//void GeometryGenerator::CreateCylinder(float bottomRadius, float topRadius, float height, UINT sliceCount, UINT stackCount, MeshData& meshData)
//{
//	meshData.Vertices.clear();
//	meshData.Indices.clear();
//
//	//
//	// Build Stacks.
//	// 
//
//	float stackHeight = height / stackCount;
//
//	// Amount to increment radius as we move up each stack level from bottom to top.
//	float radiusStep = (topRadius - bottomRadius) / stackCount;
//
//	UINT ringCount = stackCount+1;
//
//	// Compute_SRV iTriangleCount for each stack ring starting at the bottom and moving up.
//	for(UINT i = 0; i < ringCount; ++i)
//	{
//		float y = -0.5f*height + i*stackHeight;
//		float r = bottomRadius + i*radiusStep;
//
//		// iTriangleCount of ring
//		float dTheta = 2.0f*XM_PI/sliceCount;
//		for(UINT j = 0; j <= sliceCount; ++j)
//		{
//			Vertex vertex;
//
//			float c = cosf(j*dTheta);
//			float s = sinf(j*dTheta);
//
//			vertex.Position = XMFLOAT3(r*c, y, r*s);
//
//			vertex.TexC.x = (float)j/sliceCount;
//			vertex.TexC.y = 1.0f - (float)i/stackCount;
//
//			// Cylinder can be parameterized as follows, where we introduce v
//			// parameter that goes in the same direction as the v tex-coord
//			// so that the bitangent goes in the same direction as the v tex-coord.
//			//   Let r0 be the bottom radius and let r1 be the top radius.
//			//   y(v) = h - hv for v in [0,1].
//			//   r(v) = r1 + (r0-r1)v
//			//
//			//   x(t, v) = r(v)*cos(t)
//			//   y(t, v) = h - hv
//			//   z(t, v) = r(v)*sin(t)
//			// 
//			//  dx/dt = -r(v)*sin(t)
//			//  dy/dt = 0
//			//  dz/dt = +r(v)*cos(t)
//			//
//			//  dx/dv = (r0-r1)*cos(t)
//			//  dy/dv = -h
//			//  dz/dv = (r0-r1)*sin(t)
//
//			// This is unit length.
//			vertex.TangentU = XMFLOAT3(-s, 0.0f, c);
//
//			float dr = bottomRadius-topRadius;
//			XMFLOAT3 bitangent(dr*c, -height, dr*s);
//
//			XMVECTOR T = XMLoadFloat3(&vertex.TangentU);
//			XMVECTOR B = XMLoadFloat3(&bitangent);
//			XMVECTOR N = XMVector3Normalize(XMVector3Cross(T, B));
//			XMStoreFloat3(&vertex.Normal, N);
//
//			meshData.Vertices.push_back(vertex);
//		}
//	}
//
//	// Add one because we duplicate the first and last vertex per ring
//	// since the texture coordinates are different.
//	UINT ringVertexCount = sliceCount+1;
//
//	// Compute_SRV indices for each stack.
//	for(UINT i = 0; i < stackCount; ++i)
//	{
//		for(UINT j = 0; j < sliceCount; ++j)
//		{
//			meshData.Indices.push_back(i*ringVertexCount + j);
//			meshData.Indices.push_back((i+1)*ringVertexCount + j);
//			meshData.Indices.push_back((i+1)*ringVertexCount + j+1);
//
//			meshData.Indices.push_back(i*ringVertexCount + j);
//			meshData.Indices.push_back((i+1)*ringVertexCount + j+1);
//			meshData.Indices.push_back(i*ringVertexCount + j+1);
//		}
//	}
//
//	BuildCylinderTopCap(bottomRadius, topRadius, height, sliceCount, stackCount, meshData);
//	BuildCylinderBottomCap(bottomRadius, topRadius, height, sliceCount, stackCount, meshData);
//}
//
//void GeometryGenerator::BuildCylinderTopCap(float bottomRadius, float topRadius, float height, 
//											UINT sliceCount, UINT stackCount, MeshData& meshData)
//{
//	UINT baseIndex = (UINT)meshData.Vertices.size();
//
//	float y = 0.5f*height;
//	float dTheta = 2.0f*XM_PI/sliceCount;
//
//	// Duplicate cap ring iTriangleCount because the texture coordinates and normals differ.
//	for(UINT i = 0; i <= sliceCount; ++i)
//	{
//		float x = topRadius*cosf(i*dTheta);
//		float z = topRadius*sinf(i*dTheta);
//
//		// Scale down by the height to try and make top cap texture coord area
//		// proportional to base.
//		float u = x/height + 0.5f;
//		float v = z/height + 0.5f;
//
//		meshData.Vertices.push_back( Vertex(x, y, z, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, u, v) );
//	}
//
//	// Cap center vertex.
//	meshData.Vertices.push_back( Vertex(0.0f, y, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.5f) );
//
//	// Index of center vertex.
//	UINT centerIndex = (UINT)meshData.Vertices.size()-1;
//
//	for(UINT i = 0; i < sliceCount; ++i)
//	{
//		meshData.Indices.push_back(centerIndex);
//		meshData.Indices.push_back(baseIndex + i+1);
//		meshData.Indices.push_back(baseIndex + i);
//	}
//}
//
//void GeometryGenerator::BuildCylinderBottomCap(float bottomRadius, float topRadius, float height, 
//											   UINT sliceCount, UINT stackCount, MeshData& meshData)
//{
//	// 
//	// Build bottom cap.
//	//
//
//	UINT baseIndex = (UINT)meshData.Vertices.size();
//	float y = -0.5f*height;
//
//	// iTriangleCount of ring
//	float dTheta = 2.0f*XM_PI/sliceCount;
//	for(UINT i = 0; i <= sliceCount; ++i)
//	{
//		float x = bottomRadius*cosf(i*dTheta);
//		float z = bottomRadius*sinf(i*dTheta);
//
//		// Scale down by the height to try and make top cap texture coord area
//		// proportional to base.
//		float u = x/height + 0.5f;
//		float v = z/height + 0.5f;
//
//		meshData.Vertices.push_back( Vertex(x, y, z, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, 0.0f, u, v) );
//	}
//
//	// Cap center vertex.
//	meshData.Vertices.push_back( Vertex(0.0f, y, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.5f) );
//
//	// Cache the index of center vertex.
//	UINT centerIndex = (UINT)meshData.Vertices.size()-1;
//
//	for(UINT i = 0; i < sliceCount; ++i)
//	{
//		meshData.Indices.push_back(centerIndex);
//		meshData.Indices.push_back(baseIndex + i);
//		meshData.Indices.push_back(baseIndex + i+1);
//	}
//}
//
//void GeometryGenerator::CreateGrid(float width, float depth, UINT m, UINT n, MeshData& meshData)
//{
//	UINT vertexCount = m*n;
//	UINT faceCount   = (m-1)*(n-1)*2;
//
//	//
//	// Create the iTriangleCount.
//	//
//
//	float halfWidth = 0.5f*width;
//	float halfDepth = 0.5f*depth;
//
//	float dx = width / (n-1);
//	float dz = depth / (m-1);
//
//	float du = 1.0f / (n-1);
//	float dv = 1.0f / (m-1);
//
//	meshData.Vertices.resize(vertexCount);
//	for(UINT i = 0; i < m; ++i)
//	{
//		float z = halfDepth - i*dz;
//		for(UINT j = 0; j < n; ++j)
//		{
//			float x = -halfWidth + j*dx;
//
//			meshData.Vertices[i*n+j].Position = XMFLOAT3(x, 0.0f, z);
//			meshData.Vertices[i*n+j].Normal   = XMFLOAT3(0.0f, 1.0f, 0.0f);
//			meshData.Vertices[i*n+j].TangentU = XMFLOAT3(1.0f, 0.0f, 0.0f);
//
//			// Stretch texture over grid.
//			meshData.Vertices[i*n+j].TexC.x = j*du;
//			meshData.Vertices[i*n+j].TexC.y = i*dv;
//		}
//	}
// 
//    //
//	// Create the indices.
//	//
//
//	meshData.Indices.resize(faceCount*3); // 3 indices per face
//
//	// Iterate over each quad and compute indices.
//	UINT k = 0;
//	for(UINT i = 0; i < m-1; ++i)
//	{
//		for(UINT j = 0; j < n-1; ++j)
//		{
//			meshData.Indices[k]   = i*n+j;
//			meshData.Indices[k+1] = i*n+j+1;
//			meshData.Indices[k+2] = (i+1)*n+j;
//
//			meshData.Indices[k+3] = (i+1)*n+j;
//			meshData.Indices[k+4] = i*n+j+1;
//			meshData.Indices[k+5] = (i+1)*n+j+1;
//
//			k += 6; // next quad
//		}
//	}
//}
//
//void GeometryGenerator::CreateFullscreenQuad(MeshData& meshData)
//{
//	meshData.Vertices.resize(4);
//	meshData.Indices.resize(6);
//
//	// Position coordinates specified in NDC space.
//	meshData.Vertices[0] = Vertex(
//		-1.0f, -1.0f, 0.0f, 
//		0.0f, 0.0f, -1.0f,
//		1.0f, 0.0f, 0.0f,
//		0.0f, 1.0f);
//
//	meshData.Vertices[1] = Vertex(
//		-1.0f, +1.0f, 0.0f, 
//		0.0f, 0.0f, -1.0f,
//		1.0f, 0.0f, 0.0f,
//		0.0f, 0.0f);
//
//	meshData.Vertices[2] = Vertex(
//		+1.0f, +1.0f, 0.0f, 
//		0.0f, 0.0f, -1.0f,
//		1.0f, 0.0f, 0.0f,
//		1.0f, 0.0f);
//
//	meshData.Vertices[3] = Vertex(
//		+1.0f, -1.0f, 0.0f, 
//		0.0f, 0.0f, -1.0f,
//		1.0f, 0.0f, 0.0f,
//		1.0f, 1.0f);
//
//	meshData.Indices[0] = 0;
//	meshData.Indices[1] = 1;
//	meshData.Indices[2] = 2;
//
//	meshData.Indices[3] = 0;
//	meshData.Indices[4] = 2;
//	meshData.Indices[5] = 3;
//}

#pragma once
#include "CommonHeader.h"
inline static void GeometryGenerate_Plane(std::vector<std::vector<Vector3>>& points, std::vector<Vertex_PTNTB_Skinned>& iTriangleCount, std::vector<UINT>& indices)
{
	/*
	* 0 1
	* 2 3
	*/
	points.resize(1, std::vector<Vector3>(4));
	iTriangleCount.resize(4);
	iTriangleCount[0].pos0 = points[0][0] = Vector3(-0.5f, 0.5f, 0.0f);
	iTriangleCount[0].tex0 = Vector2(0.0f, 0.0f);

	iTriangleCount[1].pos0 = points[0][1] = Vector3(0.5f, 0.5f, 0.0f);
	iTriangleCount[1].tex0 = Vector2(1.0f, 0.0f);

	iTriangleCount[2].pos0 = points[0][2] = Vector3(-0.5f, -0.5f, 0.0f);
	iTriangleCount[2].tex0 = Vector2(0.0f, 1.0f);

	iTriangleCount[3].pos0 = points[0][3] = Vector3(0.5f, -0.5f, 0.0f);
	iTriangleCount[3].tex0 = Vector2(1.0f, 1.0f);

	iTriangleCount[0].normal0 = Vector3(0.0f, 0.0f, -1.0f);
	iTriangleCount[1].normal0 = Vector3(0.0f, 0.0f, -1.0f);
	iTriangleCount[2].normal0 = Vector3(0.0f, 0.0f, -1.0f);
	iTriangleCount[3].normal0 = Vector3(0.0f, 0.0f, -1.0f);
	
	indices = { 0, 1, 2, 2, 1, 3 };

	//tangent, binormal����
	//ComputeTangentBinormal(indices, iTriangleCount);
}

//�������� �����Ѵ�, subdivide
inline static void Subdivide(std::vector<Vector3>& points, std::vector<Vertex_PTNTB_Skinned>& iTriangleCount, std::vector<UINT>& indices)
{
	// Save a copy of the input geometry.
	//       v1
	//       *
	//      / \
	//     /   \
	//  m0*-----*m1
	//   / \   / \
	//  /   \ /   \
	// *-----*-----*
	// v0    m2     v2
	
	std::vector<Vector3> pointCopy = points;
	std::vector<Vertex_PTNTB_Skinned> verticesCopy = iTriangleCount;
	std::vector<UINT> indiciesCopy = indices;
	points.resize(0);
	iTriangleCount.resize(0);
	indices.resize(0);

	UINT numTriangles = indiciesCopy.size()/3;
	for(UINT i = 0; i < numTriangles; ++i)
	{
		Vertex_PTNTB_Skinned v0 = verticesCopy[indiciesCopy[i * 3 + 0]];
		Vertex_PTNTB_Skinned v1 = verticesCopy[indiciesCopy[i * 3 + 1]];
		Vertex_PTNTB_Skinned v2 = verticesCopy[indiciesCopy[i * 3 + 2]];
	
		// Generate the midpoints.
		// For subdivision, we just care about the position component.  We derive the other
		// vertex components in CreateGeosphere.
		Vertex_PTNTB_Skinned m0, m1, m2;
		m0.pos0 = Vector3(0.5f * (v0.pos0.GetX() + v1.pos0.GetX()), 0.5f * (v0.pos0.GetY() + v1.pos0.GetY()), 0.5f * (v0.pos0.GetZ() + v1.pos0.GetZ()));
		m1.pos0 = Vector3(0.5f * (v1.pos0.GetX() + v2.pos0.GetX()), 0.5f * (v1.pos0.GetY() + v2.pos0.GetY()), 0.5f * (v1.pos0.GetZ() + v2.pos0.GetZ()));
		m2.pos0 = Vector3(0.5f * (v0.pos0.GetX() + v2.pos0.GetX()), 0.5f * (v0.pos0.GetY() + v2.pos0.GetY()), 0.5f * (v0.pos0.GetZ() + v2.pos0.GetZ()));

		// Add new geometry.
		iTriangleCount.push_back(v0); points.push_back(v0.pos0);	// 0
		iTriangleCount.push_back(v1); points.push_back(v1.pos0);	// 1
		iTriangleCount.push_back(v2); points.push_back(v2.pos0);	// 2
		iTriangleCount.push_back(m0); points.push_back(m0.pos0);	// 3
		iTriangleCount.push_back(m1); points.push_back(m1.pos0);	// 4
		iTriangleCount.push_back(m2); points.push_back(m2.pos0);	// 5
 
		indices.push_back(i*6+0);
		indices.push_back(i*6+3);
		indices.push_back(i*6+5);
		
		indices.push_back(i*6+3);
		indices.push_back(i*6+4);
		indices.push_back(i*6+5);
		
		indices.push_back(i*6+5);
		indices.push_back(i*6+4);
		indices.push_back(i*6+2);
		
		indices.push_back(i*6+3);
		indices.push_back(i*6+1);
		indices.push_back(i*6+4);
	}
}

//�̺��� �̿��� ������ ��������� ������ ����� ��ü�������Ѵ�
inline static void GeometryGenerate_GeoSphere(float radius, UINT numSubdivisions, std::vector<std::vector<Vector3>>& points, std::vector<Vertex_PTNTB_Skinned>& iTriangleCount, std::vector<UINT>& indices)
{
	points.resize(1);

	// Put a cap on the number of subdivisions.
	numSubdivisions = std::min(numSubdivisions, 5u);

	// Approximate a sphere by tessellating an icosahedron.
	const float X = 0.525731f; 
	const float Z = 0.850651f;

	Vector3 pos[12] = 
	{
		Vector3(-X, 0.0f, Z),  Vector3(X, 0.0f, Z),
		Vector3(-X, 0.0f, -Z), Vector3(X, 0.0f, -Z),
		Vector3(0.0f, Z, X),   Vector3(0.0f, Z, -X),
		Vector3(0.0f, -Z, X),  Vector3(0.0f, -Z, -X),
		Vector3(Z, X, 0.0f),   Vector3(-Z, X, 0.0f),
		Vector3(Z, -X, 0.0f),  Vector3(-Z, -X, 0.0f)
	};

	UINT k[60] = 
	{
		1,4,0,  4,9,0,  4,5,9,  8,5,4,  1,8,4,    
		1,10,8, 10,3,8, 8,3,5,  3,2,5,  3,7,2,    
		3,10,7, 10,6,7, 6,11,7, 6,0,11, 6,1,0, 
		10,1,6, 11,0,9, 2,11,9, 5,2,9,  11,2,7 
	};

	iTriangleCount.resize(12);
	indices.resize(60);

	for(UINT i = 0; i < 12; ++i)
		iTriangleCount[i].pos0 = pos[i];

	for(UINT i = 0; i < 60; ++i)
		indices[i] = k[i];

	for(UINT i = 0; i < numSubdivisions; ++i)
		Subdivide(points[0], iTriangleCount, indices);

	// 1. �⺻���� UV ��� (���� ��� �����ϵ� atan2 ���� ����)
	for (UINT i = 0; i < iTriangleCount.size(); ++i)
	{
		// Project onto unit sphere.
		Vector3 n = iTriangleCount[i].pos0.Normalize();
		// Project onto sphere.
		Vector3 p = radius * n;
		iTriangleCount[i].pos0 = points[0][i] = p;
		iTriangleCount[i].normal0 = n;

		// atan2f�� -pi ~ pi�� ��ȯ�ϹǷ� 0 ~ 2pi�� ����
		float theta = atan2f(n.GetZ(), n.GetX()); // [-pi, pi]
		if (theta < 0.0f) theta += DirectX::XM_2PI;

		float phi = acosf(std::max(-1.0f, std::min(1.0f, n.GetY())));

		iTriangleCount[i].tex0 = Vector2(theta / DirectX::XM_2PI, phi / DirectX::XM_PI);
	}

	// 2. ������(Seam) ���� - �ٽ� ����
	// �ﰢ���� �ϳ��� �˻��ϸ� U ��ǥ�� �ް��ϰ� ���ϴ�(0.0 -> 1.0) �κ��� ã�� ������ �߰��Ѵ�
	for (UINT i = 0; i < indices.size(); i += 3)
	{
		UINT i0 = indices[i];
		UINT i1 = indices[i + 1];
		UINT i2 = indices[i + 2];

		Vector3 p0 = iTriangleCount[i0].pos0;
		Vector3 p1 = iTriangleCount[i1].pos0;
		Vector3 p2 = iTriangleCount[i2].pos0;

		Vector2 uv0 = iTriangleCount[i0].tex0;
		Vector2 uv1 = iTriangleCount[i1].tex0;
		Vector2 uv2 = iTriangleCount[i2].tex0;

		// �ﰢ���� �� ���� ���� UV ���̰� 0.5���� ũ�� �������� ���������� ������ ����
		// (��: �� ���� 0.1, �� ���� 0.9�� ���)
		if (abs(uv0.GetX() - uv1.GetX()) > 0.5f || abs(uv1.GetX() - uv2.GetX()) > 0.5f || abs(uv2.GetX() - uv0.GetX()) > 0.5f)
		{
			UINT idx[3] = { i0, i1, i2 };
			for (int j = 0; j < 3; ++j)
			{
				// U���� ����(0.5 �̸�) �������� ã�� �������� ����� U�� 1.0�� ������
				if (iTriangleCount[idx[j]].tex0.GetX() < 0.5f)
				{
					Vertex_PTNTB_Skinned newV = iTriangleCount[idx[j]];
					newV.tex0.SetX(newV.tex0.GetX() + 1.0f);

					// ���� ������ �����ϴ� �� �ƴ϶� �� ������ �߰��ϰ� �ε����� ��ü��
					indices[i + j] = (UINT)iTriangleCount.size();
					iTriangleCount.push_back(newV);
				}
			}
		}
	}

	//tangent, binormal����
	ComputeTangentBinormal(indices, iTriangleCount);
}

inline static void GeometryGenerate_Gizmo(std::vector<std::vector<Vector3>>& points, std::vector<Vertex_PC>& iTriangleCount, std::vector<UINT>& indices)
{
	/*
	* x 0 1
	* y 2 3
	* z 4 5
	*/
	points.resize(1, std::vector<Vector3>(6));
	iTriangleCount.resize(6);
	iTriangleCount[0].pos0 = points[0][0] = Vector3(0.0f, 0.0f, 0.0f);
	iTriangleCount[0].color0 = Vector4(1.0f, 0.0f, 0.0f, 1.0f);

	iTriangleCount[1].pos0 = points[0][1] = Vector3(1.0f, 0.0f, 0.0f);
	iTriangleCount[1].color0 = Vector4(1.0f, 0.0f, 0.0f, 1.0f);

	iTriangleCount[2].pos0 = points[0][2] = Vector3(0.0f, 0.0f, 0.0f);
	iTriangleCount[2].color0 = Vector4(0.0f, 1.0f, 0.0f, 1.0f);

	iTriangleCount[3].pos0 = points[0][3] = Vector3(0.0f, 1.0f, 0.0f);
	iTriangleCount[3].color0 = Vector4(0.0f, 1.0f, 0.0f, 1.0f);

	iTriangleCount[4].pos0 = points[0][4] = Vector3(0.0f, 0.0f, 0.0f);
	iTriangleCount[4].color0 = Vector4(0.0f, 0.0f, 1.0f, 1.0f);

	iTriangleCount[5].pos0 = points[0][5] = Vector3(0.0f, 0.0f, 1.0f);
	iTriangleCount[5].color0 = Vector4(0.0f, 0.0f, 1.0f, 1.0f);

	indices = {0, 1, 2, 3, 4, 5};
}