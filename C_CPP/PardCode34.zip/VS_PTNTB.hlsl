struct VS_INPUT
{
    float4 pos0 : POSITION0;
    float4 tex0 : TEXCOORD0;
    float4 normal0 : NORMAL0;
    float4 tangent0 : TANGENT0;
    float4 binormal0 : BINORMAL0;
};

struct VS_OUTPUT
{
    float4 pos0 : SV_POSITION;
    float4 tex0 : TEXCOORD0;
    float4 normal0 : NORMAL0;
    float4 tangent0 : TANGENT0;
    float4 binormal0 : BINORMAL0;
    //LightResources
    float4 pos1 : WORLDP0;
    float4 lightPos0 : TEXCOORD1;
    float3 lightNormal0 : NORMAL1;
};

cbuffer CB_WVPIT : register(b0)
{
    row_major float4x4 matWorld;
    row_major float4x4 matView;
    row_major float4x4 matProj;
    row_major float4x4 matInvTrans;
};

cbuffer CB_LightMat : register(b1)
{
    row_major float4x4 matLightView;
    row_major float4x4 matLightProj;
    float4 LightPos;
};

VS_OUTPUT vsmain(VS_INPUT input)
{
    VS_OUTPUT output = (VS_OUTPUT) 0;
    input.pos0.w = 1.0f;
    output.pos0 = mul(input.pos0, matWorld);
    output.pos1 = output.pos0;
    output.pos0 = mul(output.pos0, matView);
    output.pos0 = mul(output.pos0, matProj); //���ٳ������� �����Ͷ��������� ���� w������ �˾Ƽ�����ȴ�
 
    output.tex0 = input.tex0;
    
    output.normal0 = float4(mul(input.normal0.xyz, (float3x3) matInvTrans), 0.0f);
    output.tangent0 = float4(mul(input.tangent0.xyz, (float3x3) matInvTrans), 0.0f);
    output.binormal0 = float4(mul(input.binormal0.xyz, (float3x3) matInvTrans), 0.0f);
     
    //�׸��ڸ� ����� ���� ���� ���� ����� ��ȯ
    output.lightPos0 = mul(output.pos1, matLightView);
    output.lightPos0 = mul(output.lightPos0, matLightProj);
    
    //���ǹ�����
    output.lightNormal0 = normalize(LightPos.xyz - output.pos1.xyz);
    
    return output;
}