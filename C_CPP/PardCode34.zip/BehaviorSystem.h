#pragma once
#include "BaseSystem.h"
class BehaviorSystem : public BaseSystem<BehaviorSystem>
{
	friend class BaseSystem<BehaviorSystem>;	//CRTP������ ���� friend����
private:
	BehaviorSystem();
	BehaviorSystem(const BehaviorSystem&) = delete;
	BehaviorSystem& operator=(const BehaviorSystem&) = delete;
	BehaviorSystem(BehaviorSystem&&) = delete;
	BehaviorSystem& operator=(BehaviorSystem&&) = delete;

public:
	~BehaviorSystem();
	void Init();
	void Frame(float deltatime);

};
#define _BehaviorSystem BehaviorSystem::GetInstance()