#pragma once
#include "Resource.h"

class Animation : public BaseResource<Animation>
{
	friend class BaseResource<Animation>;
public:
	Animation(size_t hash, const std::wstring& szFilePath, const std::unordered_map<std::string, Bone>& boneMap, const std::vector<NodeHierarchy>& nodeHierarchy, const std::unordered_map<std::string, AnimationClip>& clips);
	Animation(const Animation&) = delete;
	Animation& operator=(const Animation&) = delete;
	Animation(Animation&&) = delete;
	Animation& operator=(Animation&&) = delete;

public:
	void GetFinalTransform(const std::string& szName, const float t, std::vector<Matrix4x4>& mats);
	const std::unordered_map<std::string, AnimationClip>& GetAnimations();
private:
	Vector3		FrameInterpolate_Vector(const std::vector<KeyFrame_Vector>& frames, const float t);
	Quaternion FrameInterpolate_Quaternion(const std::vector<KeyFrame_Quaternion>& frames, const float t);

private:
	std::unordered_map<std::string, AnimationClip> m_AnimationClip;
	std::vector<NodeHierarchy> m_Hierarchy;
	std::unordered_map<std::string, Bone> m_BoneMap;

};
inline Animation::Animation(size_t hash, const std::wstring& szFilePath, const std::unordered_map<std::string, Bone>& boneMap, const std::vector<NodeHierarchy>& nodeHierarchy, const std::unordered_map<std::string, AnimationClip>& clips)
	: BaseResource(hash, szFilePath), m_BoneMap(boneMap), m_Hierarchy(nodeHierarchy), m_AnimationClip(clips)
{

}
inline void Animation::GetFinalTransform(const std::string& szName, const float t, std::vector<Matrix4x4>& mats)
{
	// 1. ��� ���(�� ���� ��� ����)�� Root ���� ���� ����� ������ ����
	std::vector<Matrix4x4> toRoot(m_Hierarchy.size());
	mats.resize(m_BoneMap.size());

	// 2. ���� ���� ��ȸ (m_Hierarchy�� �θ� �׻� �ڽĺ��� �տ� �ִٴ� ���� �Ͽ�)
	for (UINT idx = 0; idx < m_Hierarchy.size(); idx++)
	{
		int idx_parent = m_Hierarchy[idx].idx_parent;
		std::string curName = m_Hierarchy[idx].szName_Cur;
		Matrix4x4 toParent = m_Hierarchy[idx].matRelative;
		
		if(m_AnimationClip.find(szName) != m_AnimationClip.end())
		{
			const auto& animClip = m_AnimationClip[szName];
			// �ش� ��忡 �ִϸ��̼� Ű���� �ִٸ� ����ų� ����
			if (animClip.boneFrames_Scale.find(curName) != animClip.boneFrames_Scale.end())
			{
				Vector3 vScale = FrameInterpolate_Vector(animClip.boneFrames_Scale.at(curName), t);
				Quaternion qRotate = FrameInterpolate_Quaternion(animClip.boneFrames_Rotate.at(curName), t);
				Vector3 vTranslation = FrameInterpolate_Vector(animClip.boneFrames_Translation.at(curName), t);

				// ���� �ִϸ��̼��� ������ �ʱ� ������(matRelative)�� '��ü'�մϴ�.
				toParent = GetMat_World(vScale, qRotate, vTranslation);
				//_ASEERTION_NULCHK(!std::isnan(toParent[0].GetX()), "nan");
			}
		}

		// 3. �θ��� '�̹� ����' ���� ����� ������ ����
		if (idx_parent == -1) // ��Ʈ ����� ���
		{
			toRoot[idx] = toParent;
		}
		else
		{
			toRoot[idx] = toParent * toRoot[idx_parent];
		}
		//_ASEERTION_NULCHK(!std::isnan(toRoot[idx][0].GetX()), "nan");
	}

	// 4. ��Ű�� ��� �ϼ�: vertex * offset * toRoot(����)
	for (UINT idx = 0; idx < m_Hierarchy.size(); idx++)
	{
		std::string curName = m_Hierarchy[idx].szName_Cur;
		if (m_BoneMap.find(curName) != m_BoneMap.end())
		{
			// ���̴��� ���� ���� ��� ���
			// ����: Offset(������ �� ��������) -> toRoot(�� ���� ������ �ִϸ��̼ǵ� �����)
			mats[m_BoneMap[curName].idx] = m_BoneMap[curName].matOffset * toRoot[idx];
			Matrix4x4 debug = mats[m_BoneMap[curName].idx];
			//_ASEERTION_NULCHK(!std::isnan(debug[0].GetX()), "nan");
		}
	}
}


inline const std::unordered_map<std::string, AnimationClip>& Animation::GetAnimations()
{
	return m_AnimationClip;
}


//Ư���ð� t�� ������� keyframe
inline Vector3 Animation::FrameInterpolate_Vector(const std::vector<KeyFrame_Vector>& frames, const float t)
{
	if (frames.size() <= 1)
		return frames[0].vValue;
	auto iter = std::upper_bound(frames.begin(), frames.end(), t, [](const float val, const KeyFrame_Vector& frame)
		{
			return val < frame.fTime;
		});
	UINT prv = 0, nxt = 0;
	if (iter == frames.begin()) { prv = 0; nxt = 0; }
	else if (iter == frames.begin() + frames.size()) { prv = frames.size() - 1; nxt = frames.size() - 1; }
	else { prv = (unsigned)(iter - frames.begin() - 1); nxt = (unsigned)(iter - frames.begin()); }

	double dt = frames[nxt].fTime - frames[prv].fTime;
	double amount = (dt > 0.0) ? (t - frames[prv].fTime) / dt : 0.0f;
	return lerp(frames[prv].vValue, frames[nxt].vValue, amount);
}

inline Quaternion Animation::FrameInterpolate_Quaternion(const std::vector<KeyFrame_Quaternion>& frames, const float t)
{
	if (frames.size() <= 1)
		return frames[0].qValue;
	auto iter = std::upper_bound(frames.begin(), frames.end(), t, [](const float val, const KeyFrame_Quaternion& frame)
		{
			return val < frame.fTime;
		});
	UINT prv = 0, nxt = 0;
	if (iter == frames.begin()) { prv = 0; nxt = 0; }
	else if (iter == frames.begin() + frames.size()) { prv = frames.size() - 1; nxt = frames.size() - 1; }
	else { prv = (unsigned)(iter - frames.begin() - 1); nxt = (unsigned)(iter - frames.begin()); }

	double dt = frames[nxt].fTime - frames[prv].fTime;
	double amount = (dt > 0.0) ? (t - frames[prv].fTime) / dt : 0.0f;
	return Slerp(frames[prv].qValue, frames[nxt].qValue, amount);
}



