#include "CommonHeader.h"

template<typename T>
class BaseView
{
protected:
	BaseView();
	virtual ~BaseView();
	BaseView(const BaseView&) = delete;
	BaseView& operator=(const BaseView&) = delete;
	BaseView(BaseView&&) = delete;
	BaseView& operator=(BaseView&&) = delete;
	
public:
	void ReleaseView();
	T* GetView();
	ID3D11Resource* GetBuffer();
protected:
	T* m_pView = nullptr;
};

template<typename T>
inline BaseView<T>::BaseView()
{
	std::cout << "Initialize : " << "BaseView <" << typeid(T).name() << "> Class" << '\n';
}

template<typename T>
inline BaseView<T>::~BaseView()
{
	std::cout << "Release : " << "BaseView <" << typeid(T).name() << "> Class" << '\n';
	ReleaseView();
}

template<typename T>
void inline BaseView<T>::ReleaseView()
{
	if (m_pView)
		m_pView->Release();
}

template<typename T>
inline T* BaseView<T>::GetView()
{
	return m_pView;
}

template<typename T>
inline ID3D11Resource* BaseView<T>::GetBuffer()
{
	ID3D11Resource* pResource;
	m_pView->GetResource(&pResource);
	return pResource;
}


class ShaderResourceView : public BaseView<ID3D11ShaderResourceView>
{
public:
	ShaderResourceView(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc);
	ShaderResourceView(const ShaderResourceView&) = delete;
	ShaderResourceView& operator=(const ShaderResourceView&) = delete;
	ShaderResourceView(ShaderResourceView&&) = delete;
	ShaderResourceView& operator=(ShaderResourceView&&) = delete;
	void Resize(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc);
};

class RenderTargetView : public BaseView<ID3D11RenderTargetView>
{
public:
	RenderTargetView(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_RENDER_TARGET_VIEW_DESC rtvDesc);
	RenderTargetView(const RenderTargetView&) = delete;
	RenderTargetView& operator=(const RenderTargetView&) = delete;
	RenderTargetView(RenderTargetView&&) = delete;
	RenderTargetView& operator=(RenderTargetView&&) = delete;
	void Resize(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_RENDER_TARGET_VIEW_DESC rtvDesc);
};

class DepthStencilView : public BaseView<ID3D11DepthStencilView>
{
public:
	DepthStencilView(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_DEPTH_STENCIL_VIEW_DESC dsvDesc);
	DepthStencilView(const DepthStencilView&) = delete;
	DepthStencilView& operator=(const DepthStencilView&) = delete;
	DepthStencilView(DepthStencilView&&) = delete;
	DepthStencilView& operator=(DepthStencilView&&) = delete;
	void Resize(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_DEPTH_STENCIL_VIEW_DESC dsvDesc);
};

class UnorderedAccessView : public BaseView<ID3D11UnorderedAccessView>
{
public:
	UnorderedAccessView(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_UNORDERED_ACCESS_VIEW_DESC dsvDesc);
	UnorderedAccessView(const UnorderedAccessView&) = delete;
	UnorderedAccessView& operator=(const UnorderedAccessView&) = delete;
	UnorderedAccessView(UnorderedAccessView&&) = delete;
	UnorderedAccessView& operator=(UnorderedAccessView&&) = delete;
	void Resize(ID3D11Device* pDevice, ID3D11Resource* pBuffer, D3D11_UNORDERED_ACCESS_VIEW_DESC dsvDesc);
};
