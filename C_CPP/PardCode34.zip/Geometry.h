#pragma once
#include "Resource.h"
class Geometry : public BaseResource<Geometry>
{
	friend class BaseResource<Geometry>;
public:
	Geometry(size_t hash, const std::wstring& szFilePath);
	Geometry(const Geometry&) = delete;
	Geometry& operator=(const Geometry&) = delete;
	Geometry(Geometry&&) = delete;
	Geometry& operator=(Geometry&&) = delete;

public:
	const std::map<UINT, std::vector<Vertex_PTNTB_Skinned>>& GetVertices() { return m_verticesByMaterial; }
	const std::map<UINT, std::vector<UINT>>& GetIndices() { return m_indicesByMaterial; }
	const std::vector<std::vector<Vector3>>& GetPointsByBones() { return m_pointsByBones; }
	const std::vector<std::vector<Vector3>>& GetPointsByMeshs() { return m_pointsByMeshs; }
	std::map<UINT, MTL_TEXTURES>& GetTextures() { return m_texturesByMaterial; }
	std::unordered_map<std::string, Bone>& GetBones() { return m_BoneMap; }
	std::vector<NodeHierarchy>& GetBonesHierarchy() { return m_Hierarchy; }
	std::unordered_map<std::string, AnimationClip>& GetAnimationClip() { return m_AnimationClip; }
		
private:
	void ProcessMesh(const aiScene* scene, const aiMesh* mesh, std::map<UINT, std::unordered_map<Vertex_PTNTB_Skinned, UINT, Vertex_PTNTB_Skinned_Hash>>& verticesIdentical);
	void ProcessNode(const aiScene* scene, const aiNode* node, int idx, std::map<UINT, std::unordered_map<Vertex_PTNTB_Skinned, UINT, Vertex_PTNTB_Skinned_Hash>>& verticesIdentical);
	void ProcessAnim(const aiScene* scene);

private:
	//Mesh
	std::map<UINT, std::vector<Vertex_PTNTB_Skinned>>			m_verticesByMaterial;
	std::map<UINT, std::vector<UINT>>							m_indicesByMaterial;
	std::vector<std::vector<Vector3>>							m_pointsByMeshs;
	std::vector<std::vector<Vector3>>							m_pointsByBones;
	std::map<UINT, MTL_TEXTURES>								m_texturesByMaterial;

	//Animation
	std::unordered_map<std::string, AnimationClip>				m_AnimationClip;
	std::unordered_map<std::string, Bone>						m_BoneMap;
	std::vector<NodeHierarchy>									m_Hierarchy;
};

inline Geometry::Geometry(size_t hash, const std::wstring& szFilePath) : BaseResource(hash, szFilePath)
{
	Assimp::Importer importer;

	//importer.SetPropertyBool(AI_CONFIG_IMPORT_FBX_PRESERVE_PIVOTS, false);
	//importer.SetPropertyInteger(AI_CONFIG_PP_LBW_MAX_WEIGHTS, 4);
	std::string szFullPath = _towm(szFilePath);
	unsigned int readFlag =
		aiProcess_Triangulate |
		aiProcess_SortByPType |
		//aiProcess_JoinIdenticalVertices |			//hash��� �������
		aiProcess_GenSmoothNormals |
		aiProcess_CalcTangentSpace |
		aiProcess_OptimizeMeshes |
		aiProcess_OptimizeGraph |
		aiProcess_LimitBoneWeights |
		aiProcess_PopulateArmatureData|
		aiProcess_ConvertToLeftHanded;
	const aiScene* scene = importer.ReadFile(szFullPath, readFlag);
	_ASEERTION_NULCHK(scene, "aiScene nullptr");
	std::map<UINT, std::unordered_map<Vertex_PTNTB_Skinned, UINT, Vertex_PTNTB_Skinned_Hash>> verticesIdentical;
	ProcessNode(scene, scene->mRootNode, -1, verticesIdentical);
	ProcessAnim(scene);
}


inline void Geometry::ProcessMesh(const aiScene* scene, const aiMesh* mesh, std::map<UINT, std::unordered_map<Vertex_PTNTB_Skinned, UINT, Vertex_PTNTB_Skinned_Hash>>& verticesIdentical)
{
	if (mesh->mNumVertices <= 0) return;
	UINT matIdx = mesh->mMaterialIndex;
	std::vector<UINT> vertexLookup(mesh->mNumVertices);
	std::vector<Vector3> points;
	
	//Vertices, Points, Indicies
	for (UINT i = 0; i < mesh->mNumVertices; i++)
	{
		float vx, vy, vz, uvx, uvy, nx, ny, nz, tx, ty, tz, bx, by, bz;
		vx = vy = vz = uvx = uvy = nx = ny = nz = tx = ty = tz = bx = by = bz = 0.0f;
		vx = mesh->mVertices[i].x;
		vy = mesh->mVertices[i].y;
		vz = mesh->mVertices[i].z;

		if (mesh->HasTextureCoords(0))
		{
			uvx = (float)mesh->mTextureCoords[0][i].x;
			uvy = (float)mesh->mTextureCoords[0][i].y;
		}

		if (mesh->HasNormals())
		{
			nx = mesh->mNormals[i].x;
			ny = mesh->mNormals[i].y;
			nz = mesh->mNormals[i].z;
		}

		if (mesh->HasTangentsAndBitangents())
		{
			tx = mesh->mTangents[i].x;
			ty = mesh->mTangents[i].y;
			tz = mesh->mTangents[i].z;
			bx = mesh->mBitangents[i].x;
			by = mesh->mBitangents[i].y;
			bz = mesh->mBitangents[i].z;
		}
		Vertex_PTNTB_Skinned vertex{ { vx, vy, vz }, { uvx, uvy }, { nx, ny, nz }, {tx, ty, tz}, {bx, by, bz } };
		
		auto it = verticesIdentical[matIdx].find(vertex);
		if (it == verticesIdentical[matIdx].end())
		{
			vertexLookup[i] = (UINT)m_verticesByMaterial[matIdx].size();
			verticesIdentical[matIdx][vertex] = (UINT)m_verticesByMaterial[matIdx].size();
			m_verticesByMaterial[matIdx].push_back(vertex);
			points.push_back({ vx, vy, vz });
		}
		else
		{
			vertexLookup[i] = it->second;
		}
	}
	
	m_pointsByMeshs.push_back(points);

	for (UINT i = 0; i < mesh->mNumFaces; i++)
	{
		aiFace face = mesh->mFaces[i];
		for (UINT j = 0; j < face.mNumIndices; j++)
			m_indicesByMaterial[matIdx].push_back(vertexLookup[face.mIndices[j]]);
	}

	//Bones
	if (mesh->mNumBones > 0)
	{
		//���� ��ȸ�ϸ鼭 �������� ���� �����ε���, ����ġ�� �ʱ�ȭ
		std::vector<std::vector<IWInfo>> influenceIWs(mesh->mNumVertices, std::vector<IWInfo>());
		for (UINT i = 0; i < mesh->mNumBones; i++)
		{
			aiBone* pBone = mesh->mBones[i];
			std::string boneName = pBone->mName.C_Str();
			UINT boneIndex = 0;

			// ���� ó�� �߰ߵ� ���̶�� ��Ͽ� �߰�
			if (m_BoneMap.find(boneName) == m_BoneMap.end())
			{
				boneIndex = (UINT)m_BoneMap.size();
				m_BoneMap[boneName].idx = boneIndex;
				m_BoneMap[boneName].matOffset = pBone->mOffsetMatrix;
				m_pointsByBones.push_back(std::vector<Vector3>());
			}
			else
			{
				boneIndex = m_BoneMap[boneName].idx;
			}


			// �ش� ���� ������ �ִ� �������� ��ȸ�ϸ� ����ġ ����
			for (UINT j = 0; j < pBone->mNumWeights; j++)
			{
				UINT vertexID = pBone->mWeights[j].mVertexId;
				float weight = pBone->mWeights[j].mWeight;
				influenceIWs[vertexID].push_back({ boneIndex, weight });
				m_pointsByBones[boneIndex].push_back(m_verticesByMaterial[matIdx][vertexLookup[vertexID]].pos0);	//�ö��̴����������� ���� pos����
			}
		}


		//������ �����͸� ����ȭ(�ִ�4, ����ġ��1.0)
		for (UINT i = 0; i < influenceIWs.size(); i++)
		{
			auto& weightList = influenceIWs[i];

			//����ġ ũ������� �������� ����
			std::sort(weightList.begin(), weightList.end(),
				[](const IWInfo& a, const IWInfo& b) {
					return a.weight > b.weight;
				});
			
			float totalWeight = 0.0f;

			//�ִ� 4���� �� ����¸� �����Ͽ� �ӽ� �հ� ���
			UINT activeBones = (UINT)std::min(weightList.size(), (size_t)4);

			for (UINT j = 0; j < activeBones; j++)
			{
				totalWeight += weightList[j].weight;
			}

			// ����ȭ �� ������ ����
			// �� ����ġ�� totalWeight�� ������ ���� 1.0�� �ǵ��� ����
			// ���� ������ 0���� ä��
			if (totalWeight > 0.0f)
			{
				for (UINT j = 0; j < 4; j++)
				{
					if (j < activeBones)
					{
						m_verticesByMaterial[matIdx][vertexLookup[i]].bones[j] = weightList[j].boneIdx;
						m_verticesByMaterial[matIdx][vertexLookup[i]].weights[j] = weightList[j].weight / totalWeight;
					}
					else
					{
						m_verticesByMaterial[matIdx][vertexLookup[i]].bones[j] = 0;
						m_verticesByMaterial[matIdx][vertexLookup[i]].weights[j] = 0.0f;
					}
				}
			}
			else
			{
				// ���� ����ġ ������ �ƿ� ���� �����̶�� �⺻�� ���� (ù ��° ���� 100%)
				m_verticesByMaterial[matIdx][vertexLookup[i]].bones[0] = 0;
				m_verticesByMaterial[matIdx][vertexLookup[i]].weights[0] = 1.0f;
				for (int j = 1; j < 4; j++) 
				{
					m_verticesByMaterial[matIdx][vertexLookup[i]].bones[j] = 0;
					m_verticesByMaterial[matIdx][vertexLookup[i]].weights[j] = 0.0f;
				}
			}
		}
	}

	if (matIdx >= 0)
	{
		aiMaterial* pMaterial = scene->mMaterials[mesh->mMaterialIndex];
		m_texturesByMaterial[mesh->mMaterialIndex].szMatName = pMaterial->GetName().C_Str();
		//aiTextureType_GLTF_METALLIC_ROUGHNESS is last(27)
		for (UINT type = 0; type <= aiTextureType_GLTF_METALLIC_ROUGHNESS; type++)
		{
			aiTextureType texType = (aiTextureType)type;
			for (UINT idx = 0; idx < pMaterial->GetTextureCount(texType); idx++)
			{
				aiString texPath;
				if (pMaterial->GetTexture(texType, idx, &texPath) == aiReturn_SUCCESS)
				{
					const aiTexture* pEmbeddedTexture = scene->GetEmbeddedTexture(texPath.C_Str());
					if (pEmbeddedTexture)
					{
						/*
						* mHeight�� 0�̸� �����Ͱ� ����� ����(png, jpg ��)���� �ǹ�
						* mHeight == 0�� ��: mWidth = Byte Size (���� �뷮)
						* mHeight > 0�� �� : mWidth = Pixel Width(�̹��� �ʺ�)
						*/
						if (pEmbeddedTexture->mHeight == 0)
						{
							ScratchImage srcatchImage;
							LoadFromWICMemory(
								reinterpret_cast<const uint8_t*>(pEmbeddedTexture->pcData), 
								static_cast<size_t>(pEmbeddedTexture->mWidth), 
								DirectX::WIC_FLAGS_NONE,
								nullptr,
								srcatchImage);
							m_texturesByMaterial[mesh->mMaterialIndex].type_textures_image[texType].push_back(std::move(srcatchImage));
						}
					}
					//�ܺΰ������
					m_texturesByMaterial[mesh->mMaterialIndex].type_textures_path[texType].push_back(texPath.C_Str());
				}
			}
		}
	}
}

inline void Geometry::ProcessNode(const aiScene* scene, const aiNode* node, int idx, std::map<UINT, std::unordered_map<Vertex_PTNTB_Skinned, UINT, Vertex_PTNTB_Skinned_Hash>>& verticesIdentical)
{
	NodeHierarchy curNode;
	int curidx = m_Hierarchy.size();
	curNode.idx_parent = idx;
	curNode.matRelative = node->mTransformation;
	curNode.szName_Parent = idx == -1 ? "Ancestor" : m_Hierarchy[idx].szName_Cur;
	curNode.szName_Cur = node->mName.C_Str();
	m_Hierarchy.push_back(curNode);
	for (UINT i = 0; i < node->mNumMeshes; i++)
	{
		ProcessMesh(scene, scene->mMeshes[node->mMeshes[i]], verticesIdentical);
	}

	for (UINT i = 0; i < node->mNumChildren; i++)
	{
		ProcessNode(scene, node->mChildren[i], curidx, verticesIdentical);
	}
}

//AnimationClip(�ִϸ��̼Ǻ�)�� ������������ �� ����(�����Ӱ���)���°Բ� S,R,T�� �����Ѵ�
inline void Geometry::ProcessAnim(const aiScene* scene)
{
	for (UINT i = 0; i < scene->mNumAnimations; i++) 
	{
		aiAnimation* aiAnim = scene->mAnimations[i];
		AnimationClip animClip;
		animClip.szName = aiAnim->mName.C_Str();
		animClip.fDuration = (float)aiAnim->mDuration;
		animClip.fTicksPerSecond = (float)aiAnim->mTicksPerSecond != 0 ? (float)aiAnim->mTicksPerSecond : 25.0f;

		for (UINT j = 0; j < aiAnim->mNumChannels; j++) 
		{
			aiNodeAnim* channel = aiAnim->mChannels[j];
			std::string boneName = channel->mNodeName.C_Str();

			for (UINT k = 0; k < channel->mNumScalingKeys; k++)
			{
				KeyFrame_Vector kfScale;
				kfScale.fTime = (float)channel->mScalingKeys[k].mTime;
				kfScale.vValue = Vector3(channel->mScalingKeys[k].mValue.x, channel->mScalingKeys[k].mValue.y, channel->mScalingKeys[k].mValue.z);
				animClip.boneFrames_Scale[boneName].push_back(kfScale);
			}

			for (UINT k = 0; k < channel->mNumRotationKeys; k++)
			{
				KeyFrame_Quaternion kfRotate;
				kfRotate.fTime = (float)channel->mRotationKeys[k].mTime;
				kfRotate.qValue = Quaternion(channel->mRotationKeys[k].mValue.w, channel->mRotationKeys[k].mValue.x, channel->mRotationKeys[k].mValue.y, channel->mRotationKeys[k].mValue.z);
				animClip.boneFrames_Rotate[boneName].push_back(kfRotate);
			}
			
			for (UINT k = 0; k < channel->mNumPositionKeys; k++)
			{
				KeyFrame_Vector kfPosition;
				kfPosition.fTime = (float)channel->mPositionKeys[k].mTime;
				kfPosition.vValue = Vector3(channel->mPositionKeys[k].mValue.x, channel->mPositionKeys[k].mValue.y, channel->mPositionKeys[k].mValue.z);
				animClip.boneFrames_Translation[boneName].push_back(kfPosition);
			}
		}
		m_AnimationClip[animClip.szName] = animClip;
	}
}

