#pragma once
#include "Resource.h"

class Texture : public BaseResource<Texture>
{
	friend class BaseResource<Texture>;
public:
	Texture(size_t hash, const std::wstring& szFilePath, ScratchImage&& scratchIamge);
	Texture(size_t hash, const std::wstring& szFilePath);
	Texture(size_t hash, const std::wstring& szFilePath, size_t hashSRV);
	Texture(const Texture&) = delete;
	Texture& operator=(const Texture&) = delete;
	Texture(Texture&&) = delete;
	void SetSRV(size_t hashSRV);
	size_t GetSRV() const;
	const ScratchImage* GetImage() const;
private:
	size_t m_lSRV;
	ScratchImage m_ScratchImage;
};

//�������̵����� ������ü(scratchImage)�� ������� �淮������� �����´�
inline Texture::Texture(size_t hash, const std::wstring& szFilePath, ScratchImage&& scratchIamge) : BaseResource(hash, szFilePath)
{
	m_ScratchImage = std::move(scratchIamge);
}

inline Texture::Texture(size_t hash, const std::wstring& szFilePath) : BaseResource(hash, szFilePath)
{
	std::wstring extension = szFilePath.substr(szFilePath.find_last_of('.'));
	HRESULT hr;
	if(extension == L".dds")
		hr = DirectX::LoadFromDDSFile(szFilePath.c_str(), DirectX::DDS_FLAGS::DDS_FLAGS_NONE, nullptr, m_ScratchImage);
	else
		hr = DirectX::LoadFromWICFile(szFilePath.c_str(), DirectX::WIC_FLAGS::WIC_FLAGS_IGNORE_SRGB, nullptr, m_ScratchImage);
	if (hr == S_OK) return;
	
	//���ϸ������� ����߰�
	std::wstring filePath = g_initpath_Texture;
	auto lastSlash = szFilePath.find_last_of(L"\\/");
	if (lastSlash != std::wstring::npos)
		filePath += szFilePath.substr(lastSlash + 1);
	else
		filePath += szFilePath;
	if (extension == L".dds")
		hr = DirectX::LoadFromDDSFile(filePath.c_str(), DirectX::DDS_FLAGS::DDS_FLAGS_NONE, nullptr, m_ScratchImage);
	else
		hr = DirectX::LoadFromWICFile(filePath.c_str(), DirectX::WIC_FLAGS::WIC_FLAGS_IGNORE_SRGB, nullptr, m_ScratchImage);
	if (hr == S_OK) return;

	hr = DirectX::LoadFromWICFile(L"../Assets/Textures/brick.png", WIC_FLAGS_IGNORE_SRGB, nullptr, m_ScratchImage);
	if (hr == S_OK) return;
	_ASEERTION_CREATE(FAILED(hr), "LoadTexture not successfully");
}

inline Texture::Texture(size_t hash, const std::wstring& szFilePath, size_t hashSRV) : BaseResource(hash, szFilePath), m_lSRV(hashSRV)
{
}

inline void Texture::SetSRV(size_t hashSRV)
{
	m_lSRV = hashSRV;
}

inline size_t Texture::GetSRV() const
{
	return m_lSRV;
}

inline const ScratchImage* Texture::GetImage() const
{
	return &m_ScratchImage;
}


