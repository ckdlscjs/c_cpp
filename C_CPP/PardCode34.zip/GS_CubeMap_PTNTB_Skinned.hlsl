struct VS_OUTPUT
{
    float4 pos0 : SV_POSITION;
    float4 tex0 : TEXCOORD0;
    float4 normal0 : NORMAL0;
    float4 tangent0 : TANGENT0;
    float4 binormal0 : BINORMAL0;
    uint4 bones : BONES0;
    float4 weights : WEIGHTS0;
};

struct GS_OUTPUT
{
    float4 pos0 : SV_POSITION; //��������
    float4 tex0 : TEXCOORD0; //�ؽ�����ǥ
    float4 normal0 : NORMAL0; //�븻��
    float4 tangent0 : TANGENT0;
    float4 binormal0 : BINORMAL0;
    uint rtvIdx : SV_RenderTargetArrayIndex; // ��� ť��� �鿡 �׸��� ���� (0~5)
    //LightResources
    float4 pos1 : WORLDP0; //���庯ȯ������
    float4 lightPos0 : TEXCOORD1;
    float3 lightNormal0 : NORMAL1;
};

cbuffer CB_WVPIT : register(b0)
{
    row_major float4x4 matWorld;
    row_major float4x4 matView;
    row_major float4x4 matProj;
    row_major float4x4 matInvTrans;
};

cbuffer CB_LightMat : register(b1)
{
    row_major float4x4 matLightView;
    row_major float4x4 matLightProj;
    float4 LightPos;
};

cbuffer CB_CubeMap : register(b7)
{
    row_major float4x4 matView_Cube[6];
};


[maxvertexcount(18)] //3*6
void gsmain(triangle VS_OUTPUT input[3], inout TriangleStream<GS_OUTPUT> outStream)
{
    float4 worldPos[3];
    float4 worldNormal[3];
    float4 worldTangent[3];
    float4 worldBinormal[3];

    for (int i = 0; i < 3; ++i)
    {
        worldPos[i] = mul(float4(input[i].pos0.xyz, 1.0f), matWorld);
        worldNormal[i] = float4(normalize(mul(input[i].normal0.xyz, (float3x3) matInvTrans)), 0.0f);
        worldTangent[i] = float4(normalize(mul(input[i].tangent0.xyz, (float3x3) matInvTrans)), 0.0f);
        worldBinormal[i] = float4(normalize(mul(input[i].binormal0.xyz, (float3x3) matInvTrans)), 0.0f);
    }
    
    for (int idx = 0; idx < 6; idx++)
    {
        for (int v = 0; v < 3; ++v)
        {
            GS_OUTPUT output;
            // Render Target Array Index ���� (0~5)
            output.rtvIdx = idx;
            
            // �� ���� View �� Proj ��� ����
            output.pos0 = output.pos1 = worldPos[v];
            output.pos0 = mul(output.pos0, matView_Cube[idx]);
            output.pos0 = mul(output.pos0, matProj);
            
            output.normal0 = worldNormal[v];
            output.tangent0 = worldTangent[v];
            output.binormal0 = worldBinormal[v];
            output.tex0 = input[v].tex0;
            
            //�׸��ڸ� ����� ���� ���� ���� ����� ��ȯ
            output.lightPos0 = mul(output.pos1, matLightView);
            output.lightPos0 = mul(output.lightPos0, matLightProj);
    
            //���ǹ�����
            output.lightNormal0 = normalize(LightPos.xyz - output.pos1.xyz);
            
            outStream.Append(output);
        }
        
        // �ﰢ�� �ϳ�(�� �ϳ�) �Ϸ� �� ��Ʈ�� �����
        outStream.RestartStrip();
    }
}