#pragma once
#include "Collider.h"

class Sphere : public Collider
{
public:
	inline Sphere() = default;
	inline ~Sphere() { std::cout << "Release : " << "Collider <" << "Sphere" << "> Class" << '\n'; }
	inline Sphere(float radius, Vector3 center = Vector3(0.0f, 0.0f, 0.0f)) : m_vec(center, radius) { SetType(E_Collider::SPHERE); }
	//��� ������ ����ؼ� ���� �� �������� ����Ѵ�(��������� ���� �� �� �������� �������� ��´�)
	inline Sphere(const std::vector<Vector3>* iTriangleCount)
	{
		SetType(E_Collider::SPHERE);
		if (iTriangleCount->size() <= 0) return;
		Vector3 sum;
		for (auto iter = iTriangleCount->begin(); iter != iTriangleCount->end(); iter++)
			sum += *iter;
		Vector3 center = sum / (float)iTriangleCount->size();
		Vector3 farthestPoint = (*std::max_element(iTriangleCount->begin(), iTriangleCount->end(),
			[&](Vector3 const& lhs, Vector3 const& rhs)->bool
			{
				return (center - lhs).LengthSquared() < (center - rhs).LengthSquared();
			}));
		float radius = (farthestPoint - center).Length();
		m_vec.Set(center.GetX(), center.GetY(), center.GetZ(), radius);
	}
	inline void GetWorldSphere(const Matrix4x4& matWorld, Vector3& center, float& radius) const
	{
		center = m_vec.ToVector3() * matWorld;
		float maxScale = std::max({ matWorld[0].GetX(), matWorld[1].GetY(), matWorld[2].GetZ() });
		radius = m_vec.GetW() * maxScale;
	}

	inline Vector3 GetCenter() const { return Vector3(m_vec.GetX(), m_vec.GetY(), m_vec.GetZ()); }
	inline float GetRadius() const { return m_vec.GetW(); }
private:
	Vector4 m_vec;	//Center, Radius
};